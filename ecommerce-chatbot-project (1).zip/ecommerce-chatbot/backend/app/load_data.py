import pandas as pd

def load_products():
    df = pd.read_csv("products.csv")
    print(df.head())
