from fastapi import APIRouter, Body
from ..schemas.chat_schema import ChatRequest, ChatResponse
from ..services.chat_service import handle_user_query

router = APIRouter()

@router.post("/chat", response_model=ChatResponse)
def chat_endpoint(request: ChatRequest):
    return handle_user_query(request)
