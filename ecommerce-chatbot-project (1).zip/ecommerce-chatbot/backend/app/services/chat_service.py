def handle_user_query(request):
    query = request.query.lower()
    if "top 5" in query:
        return {"answer": "The top 5 products are A, B, C, D, E."}
    elif "status of order" in query:
        return {"answer": "Order 12345 is shipped."}
    else:
        return {"answer": "I'm not sure, please refine your question."}
